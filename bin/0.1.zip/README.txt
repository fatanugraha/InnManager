default password for user Administrator:

User Name: admin
Password : admin

please change password ASAP.

-----------------------------------------

If you're not using Microsoft Windows operating system
you must download the sqlite3 driver according to your
current operating system.